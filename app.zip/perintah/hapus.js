module.exports = {
  kiel: { 
    nama: "hapus", 
    penulis: "Hady Zen", 
    kuldown: 6,
    peran: 0,
    tutor: "<reply>"
  }, 
  
  Hasum: async function ({ api, event }) {
    api.unsendMessage(event.messageReply.messageID);
  }
};
