![ayano](https://raw.githubusercontent.com/HadyZen/Ayanokoji-Kiyotaka/refs/heads/main/assets/ayanokoji.png) 

<h1 align="center">𝗔𝘆𝗮𝗻𝗼𝗸𝗼𝗷𝗶 𝗞𝗶𝘆𝗼𝘁𝗮𝗸𝗮 ⚡</h1>

> 𝚂𝚎𝚖𝚞𝚊 𝚘𝚛𝚊𝚗𝚐 𝚑𝚊𝚗𝚢𝚊𝚕𝚊𝚑 𝚊𝚕𝚊𝚝 <br>

![hady](https://skillicons.dev/icons?i=html,css,js,nodejs,bash&theme=dark) 

## 𝗔𝗗𝗠𝗜𝗡 🜲

Nama: Hadi Pranata <br>
Facebook: https://www.facebook.com/hady.zen.in <br>
Tiktok: https://www.tiktok.com/@hady.zen 

## SPONSOR 🜲

Website: https://hady-zen-web.koyeb.app/ <br>
Bot asli: https://green-unique-eustoma.glitch.me/ <br>
App: https://raw.githubusercontent.com/HadyZen/hady-zen-api/refs/heads/main/Tsukihime.apk

## TUTOR 🜲

1. Unduh kiwi browser di play store <br>
```hady
https://play.google.com/store/apps/details?id=com.kiwibrowser.browser
```
2. Buka url dibawah ini di kiwi browser <br>
```hady
https://glitch.com
```
3. Masuk ke akun glitch mu atau buat <br>
4. Buat project baru dan masukkan url ini <br>
```hady
https://github.com/HadyZen/Ayanokoji-Kiyotaka.git
```
5. Unduh cookie editor dibawah ini <br> 
```hady
https://raw.githubusercontent.com/HadyZen/Ayanokoji-Kiyotaka/refs/heads/main/assets/cookie.zip
```
6. Masukkan file cookie editor ke kiwi extension <br>
7. Buka url dibawah ini di kiwi browser <br>
```hady
https://www.facebook.com
``` 
8. Masuk ke akun facebook yang ingin dijadikan bot <br>
9. Klik titik tiga di kiwi lalu geser kebawah <br>
10. Pilih cookie editor lalu klik <br>
11. Klik export atau tanda keluar, pilih format json <br>
12. Buka file akun.txt di project mu lalu ganti isinya <br>
13. Ubah kiyotaka.json sebagaimana yang kamu mau <br>
14. Buka terminal lalu ketik kode ini <br> 
```hady
npm start
```
