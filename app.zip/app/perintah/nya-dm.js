module.exports = {
  kiel: {
    nama: "nya-dm",
    penulis: "Hady Zen",
    kuldown: 0,
    peran: 0,
    tutor: ""
  },
  Hasumi: async function({ api, event }) {
    api.sendMessage("Nya.", event.threadID);
    api.sendMessage("Nyaw.", event.senderID);
  }
};